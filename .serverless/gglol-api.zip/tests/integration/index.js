1. create a new account
2. Associate CC and Deposit first money
3. pull up contest (matches)
4. View a contest (match)
5. Bet on a specific item
6. System awards the winner of a specific bet.
7. View Profile
8. Deposit More Funds
9. Withdraw funds
