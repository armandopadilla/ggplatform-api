// @todo
const sendPush = (text) => {
  // Grab the text
  // Do the push
};

const sendEmail = (subject, body, to) => {

};


module.exports = {
  sendPush,
  sendEmail,
};
