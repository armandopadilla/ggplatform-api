// End and distribute the pot.
// How does a contest get flagged as finished???
