/**
 * Content API - Manage content that is not necessarily tied to a contest.
 * @type {{}}
 */
// GET - /content

module.exports = {

}