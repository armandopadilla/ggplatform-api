const response = require('./responseHandlers');
const auth = require('./auth');

module.exports = {
  response,
  auth,
};
